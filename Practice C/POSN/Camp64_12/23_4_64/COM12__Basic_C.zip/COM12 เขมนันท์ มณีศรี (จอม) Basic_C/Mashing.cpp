#include <stdio.h>

int main() {
    double ft, in;
    printf("Part 1; Enter value (ft) : ");
    scanf("%lf", &ft);
    printf("This value in cm is %.2lf\n", ft*30.48);
    printf("Part 2; Enter value (in) : ");
    scanf("%lf", &in);
    printf("This value in cm is %.2lf\n", in*2.54);
    printf("Part 3; Enter value (ft and in) : ");
    scanf("%lf %lf", &ft, &in);
    printf("This value in cm is %.2lf\n", ft*30.48+in*2.54);
    return 0;
}
