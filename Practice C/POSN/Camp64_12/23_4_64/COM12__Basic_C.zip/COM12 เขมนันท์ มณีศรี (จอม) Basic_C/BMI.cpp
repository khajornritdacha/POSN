#include <stdio.h>

int main() {
    double weight, height;
    printf("Enter your weight (kg) and height (cm) : ");
    scanf("%lf %lf", &weight, &height);
    double bmi = weight/(height*height/10000);
    printf("%.3lf\n", bmi);
    if(bmi < 18.5) {
        printf("Underweight");
    }
    else if(bmi <= 22.9) {
        printf("Healthy weight");
    }
    else if(bmi <= 24.9) {
        printf("Overweight");
    }
    else if(bmi <= 29.9) {
        printf("Fat");
    }
    else {
        printf("Dangerous fat");
    }
    return 0;
}


//<= 18.5 low
//<= 22.9 normal
//<= 24.9 overflow
//<= 29.9 fat
//> 30 danger
