#include <stdio.h>
#define PI 3.14
#define NAME "SASALAK"
#define CH 'a'

int main() {
    printf("PI = %f\n", PI);
    printf("NAME = %s\n", NAME);
    printf("PI = %c\n", CH);
    return 0;
}
