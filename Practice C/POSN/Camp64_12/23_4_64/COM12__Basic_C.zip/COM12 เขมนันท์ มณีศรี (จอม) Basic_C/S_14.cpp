#include <stdio.h>

main() {
    int a, b, c;
    printf("Enter three integer numbers : ");
    scanf("%d %d %d", &a, &b, &c);
    printf("a = %d b = %d c = %d\n", a, b, c);
}
