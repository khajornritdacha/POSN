#include <stdio.h>

int main() {
    double farm, work, wah;
    scanf("%lf %lf %lf", &farm, &work, &wah);
    wah += farm*400+work*100;
    printf("%.2lf", wah/400/2.53);
    return 0;
}
