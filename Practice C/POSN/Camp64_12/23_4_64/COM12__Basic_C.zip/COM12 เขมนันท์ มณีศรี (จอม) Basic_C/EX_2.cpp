#include <stdio.h>

int main() {
    char sex;
    printf("You are male (M) or female (F) ?\n");
    scanf("%c", &sex);
    printf("You are sex is %c.\n", sex);
    return 0;
}
