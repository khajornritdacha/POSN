#include <stdio.h>
#include <conio.h>

int main() {
    char ch;
    printf("Please type your character : ");
    ch = getchar();
    printf("The first character you entered is : %c\n", ch);
    return 0;
}
