#include <stdio.h>

int main() {
    double a, b, c;
    scanf("%lf %lf %lf", &a, &b, &c);
    printf("%.2lf", (a+b+c)*0.9);
    return 0;
}
