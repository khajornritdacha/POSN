#include <stdio.h>

int main() {
    int length, width;
    scanf("%d %d", &width, &length);
    printf("Area : %d\n",width*length);
    printf("Perimeter : %d\n", 2*(width+length));
    return 0;
}
