#include <stdio.h>

int main() {
    printf("== Welcome == \n\n");
    printf("Alert\a\n");
    printf("1 2 \b3 4\n");
    printf("backslash \\ \n");
    printf("show \" \n");
    printf("show \'hello\' \n");
    printf("ascii \123 \n");
    printf("ascii \x2e \n");
    return 0;
}
