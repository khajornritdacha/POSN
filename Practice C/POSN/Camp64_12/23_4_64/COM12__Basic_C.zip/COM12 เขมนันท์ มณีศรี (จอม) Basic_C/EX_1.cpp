#include <stdio.h>
#include <conio.h>

main() {
    printf("Silpakorn University\n");
    printf("Computer\n");
    getch();
}
