#include <stdio.h>

int main() {
    printf("Answer is %d\n", 250+43);
    printf("%d %d\n", 5-3, 10-2);
    printf("%d\n", 5*5);
    printf("%d\n", 7/3);
    printf("%d\n", 7%3);
    return 0;
}
