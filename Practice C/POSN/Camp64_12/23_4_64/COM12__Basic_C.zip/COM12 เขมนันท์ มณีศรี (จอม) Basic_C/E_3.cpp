#include <stdio.h>

int main() {
    int age = 02;
    char sex = 'f';
    float grade = 3.14;
    char name[10] = "malee";
    printf("You are %s\n", name);
    printf("You are %c\n", sex);
    printf("You are %d years old\n", age);
    printf("You grade is %f\n", grade);
    return 0;
}
