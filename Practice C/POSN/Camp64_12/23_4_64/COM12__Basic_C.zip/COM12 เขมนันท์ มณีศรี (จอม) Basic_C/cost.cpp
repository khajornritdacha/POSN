#include <stdio.h>

int main() {
    double cost;
    for(int i = 0; i < 10; i++) {
        scanf("%lf", &cost);
        printf("%.2lf\n", cost*1.2);
    }
    return 0;
}
