#include <vector>

void init_monkeys(std::vector<int> P, int Q);
long long minimum_branches(int L, int R);