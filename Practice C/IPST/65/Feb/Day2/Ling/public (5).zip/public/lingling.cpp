#include "lingling.h"
#include <vector>

void init_monkeys(std::vector<int> P, int Q){
  int N = P.size();
  // edit this function
}

long long minimum_branches(int L, int R){
  // edit this function
  return -1;
}