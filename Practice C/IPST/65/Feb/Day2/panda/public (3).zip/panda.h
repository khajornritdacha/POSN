#include <vector>
#include <utility>
void initialize(int N,int M,int S,std::vector<std::vector<int> >R);
void panda_spawn(int P,int L,int X);
void panda_evac(int P,int L,int X);
int travel(int A,int B);
