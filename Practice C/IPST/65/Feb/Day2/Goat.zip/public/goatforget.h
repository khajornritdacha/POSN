#include <vector>

std::vector<std::vector<int> > recover_map(int N, int M, int Q);
int talk_tae(int x);