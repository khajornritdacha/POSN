#include "community.h"
#include <vector>

int minimum_cost(int N, std::vector<int> w){
  // edit this function
  return 0;
}