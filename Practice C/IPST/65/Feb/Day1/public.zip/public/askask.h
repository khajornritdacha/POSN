#include <vector>

std::vector<int> find_bombs(int N);
std::vector<bool> analyse(std::vector<std::vector<int>> Z);