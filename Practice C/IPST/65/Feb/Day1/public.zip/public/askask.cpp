#include "askask.h"
#include <vector>

std::vector<int> find_bombs(int N){
  // edit this function
  return {0, 0};
}