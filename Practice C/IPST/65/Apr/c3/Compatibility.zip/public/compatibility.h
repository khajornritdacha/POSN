#include <vector>

long long maximum_incompatibility(std::vector<std::vector<int>> A);