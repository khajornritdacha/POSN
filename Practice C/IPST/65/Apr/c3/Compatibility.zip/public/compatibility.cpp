#include "compatibility.h"

long long maximum_incompatibility(std::vector<std::vector<int>> A) {
  int m = A.size();
  int n = A[0].size();
  return 0ll;
}