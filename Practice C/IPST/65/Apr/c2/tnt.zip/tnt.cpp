#include "tnt.h"
#include<vector>
std::vector<int>find_truck(int N)
{
    std::vector<int>Truck;
    return Truck;
}
