#include<vector>
bool find_tnt(std::vector<int>city);
std::vector<int>find_truck(int N);
