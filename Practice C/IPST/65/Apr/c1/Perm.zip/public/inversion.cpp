#include "inversion.h"
#include <vector>

std::vector<int> find_permutation(int n, long long inversion) {
  return std::vector<int>(n, 0);
}