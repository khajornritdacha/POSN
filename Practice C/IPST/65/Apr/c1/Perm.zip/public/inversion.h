#ifndef _INVERSION_H_
#define _INVERSION_H_
#include <vector>

long long swap_and_report(int, int);

std::vector<int> find_permutation(int, long long);

#endif