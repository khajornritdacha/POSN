#include "numagain.h"
#include <vector>
int find_ans(std::vector<int>number)
{
    return 0;
}
