#include <vector>
int find_ans(std::vector<int>number);
