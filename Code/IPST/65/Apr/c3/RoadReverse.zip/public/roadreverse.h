#ifndef _ROADREVERSE_H_
#define _ROADREVERSE_H_

#include <vector>

int count_roads(int N, int M, int K,
		std::vector<std::vector<int>> S,
		std::vector<std::pair<int,int>> R);

#endif
