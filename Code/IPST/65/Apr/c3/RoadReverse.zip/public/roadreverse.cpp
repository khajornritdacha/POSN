#include "roadreverse.h"

int count_roads(int N, int M, int K,
		std::vector<std::vector<int>> S,
		std::vector<std::pair<int,int>> R)
{
  return 0;
}
