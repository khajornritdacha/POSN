#include<vector>
#include<utility>
void initialize(int N, int Q, std::vector<int> W, std::vector<std::pair<int,int> > R)
{
    return;
}
long long query(int A, int B, int X)
{
    return 0;
}
