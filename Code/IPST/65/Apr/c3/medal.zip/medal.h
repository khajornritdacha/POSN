#ifndef MEDAL_H
#define MEDAL_H
#include<vector>
#include<utility>
void initialize(int N, int Q, std::vector<int> W, std::vector<std::pair<int,int> > R);
long long query(int A, int B, int X);
#endif
