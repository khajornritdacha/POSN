#include <vector>

void init_machine(int N, int M, int K, int Q, std::vector<int> x, std::vector<int> y);

int send_ball(int c, int s, long long t);

