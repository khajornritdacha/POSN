#include "onepath.h"
#include <vector>
#include <utility>

bool is_dangerous(int u, int v) {
  return u == v;
}

void build_road(int u, int v) {
  return;
}

void initialize(int N, int M, int Q, std::vector<std::pair<int,int>> R) {
  return;
}
