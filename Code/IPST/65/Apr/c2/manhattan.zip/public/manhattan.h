#include <cstdio>
#include <vector>

long long minimum_capacity(int N, int M, int G, int L, std::vector<int> x,
                           std::vector<int> y, std::vector<int> u,
                           std::vector<int> v, std::vector<int> w,
                           std::vector<int> g, std::vector<int> l);