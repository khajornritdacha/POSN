#ifndef _ASFXXX_H_
#define _ASFXXX_H_
#include <string>

std::string A(int T, int C);

#endif
