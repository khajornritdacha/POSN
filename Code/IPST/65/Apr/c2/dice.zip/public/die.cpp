#include "die.h"

std::string A(int T, int C)
{
  return ">";
}
