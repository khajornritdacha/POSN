Testcases are generated with Codeforces Polygon. So, to read more about "testlib.h", one can follow this link 
https://codeforces.com/testlib

"files"
Inside files folder, there are generator for each of 3 subtasks, validators(check whether testcases correspond with
constraint or not), and checker(just compare a string which may not be required).

"solutions"
There are 3 solutions inside solutions folder.
ModelSol is the main solution which yield 100 scores.
Sub1 is for subtasks 1 which brute-forces.
Sub2 is for subtasks 2 which satisfies only the special case where D = maximum of House's Health. This sol use binary search and data structure but this solution is not correct for any other subtasks

"statement"
This folder contains .pdf and .tex files of the problem.

"testcases"
There are tescases for each of 3 subtasks inside solutions folder.
