#include<bits/stdc++.h>
using namespace std;
int n,a,b,c,ans;
int main(){
	scanf("%d%d%d%d",&n,&a,&b,&c);
	printf("%d",(2*a+2)*(3*a-2));
}
